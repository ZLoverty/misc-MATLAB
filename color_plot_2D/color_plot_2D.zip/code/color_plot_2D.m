function color_plot_2D(data, Marker, MarkerFaceColor, colorScheme)
% Example (t, OP, E)
% data = readXYData(dataDir, numcol)
% colorScheme = 1;
% color_plot_2D(data, colorScheme);
% Note: colorScheme can only be 1, other schemes will be implemented later.
timeMap = [];
t_original = data(:, 1);
OP = data(:, 2);
E = data(:, 3);
t_total = max(t_original) - min(t_original);
t_resc = (t_original-min(t_original))/(1/0.7)/t_total;
if colorScheme == 1
    cohsv_h = 0.7-t_resc;
    for i = 1: numel(OP)
        cohsv = [cohsv_h(i), 1, 1];
        corgb = hsv2rgb(cohsv);
        h = line(OP(i), E(i), 'MarkerFaceColor', corgb,...
            'MarkerEdgeColor', 0.7*corgb,...
            'LineWidth', 2,...
            'Marker', Marker, 'MarkerSize', 10);
%         text(OP(i), E(i), num2str(cohsv(1)));
        if MarkerFaceColor ~= -1
            set(h, 'MarkerFaceColor', 'none');
        end
    end
end
set(gca,...
    'FontSize', 16,...
    'Box', 'on',...
    'LineWidth', 1.5,...
    'XScale', 'linear');
xlabel('Order Parameter', 'interpreter', 'latex', 'FontSize', 24);
ylabel('$E_k$', 'interpreter', 'latex', 'FontSize', 24);
end
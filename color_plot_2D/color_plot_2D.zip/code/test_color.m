dataDir1 = 'C:\Users\liux3141\Desktop\norm_t_frac_energy60x10fps80n0_75pg25r_30perl_10um.dat';
dataDir2 = 'C:\Users\liux3141\Desktop\norm_t_frac_energy60x10fps80n0_100pg0r_30perl_10um.dat';
data1 = readXYData(dataDir1, 3);
data2 = readXYData(dataDir2, 3);
colorScheme = 1;
hold on
color_plot_2D(data1,'o', -1, colorScheme);
color_plot_2D(data2,'s', 1, colorScheme);
timeMapSimpleHSV = [0.7-linspace(0, 0.7, 64); ones(2, 64)]';
timeMapSimple = hsv2rgb(timeMapSimpleHSV);
colormap(timeMapSimple);
c = colorbar;
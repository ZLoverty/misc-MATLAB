function data = readXYData(dataDir, numcol)
fid = fopen(dataDir);
data = fscanf(fid, '%f', [numcol inf]);
data = data';
fclose(fid);
end